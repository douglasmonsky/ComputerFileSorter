import os

#Get current working directory.
root_path = os.path.dirname(os.path.realpath(__file__))
print(root_path)

dir_names = []
file_names = []

for (dirpath, dirnames, filenames) in os.walk(root_path):
    dir_names.extend(dirnames)
    file_names.extend(filenames)
    break

print(dir_names)
print(file_names)


#Get current working directory.
root_path = os.path.dirname(os.path.realpath(__file__))
print(root_path)

#Create a list of file extensions encountered.
